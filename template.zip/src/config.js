import id from './lang/id.json'

export const lang = id